# Retrieve {{ model_verbose_name|title }} Playbooks:

Make GET request to this resource to retrieve a list of playbooks available
for {{ model_verbose_name|anora }}.
