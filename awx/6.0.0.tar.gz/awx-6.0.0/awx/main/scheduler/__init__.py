# Copyright (c) 2017 Ansible, Inc.
#

from awx.main.scheduler.task_manager import TaskManager # noqa
